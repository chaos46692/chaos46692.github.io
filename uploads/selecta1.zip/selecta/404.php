<?php get_header(); ?>
 <div class="post">
    <h2 class="title">Sorry!</h2>
    <div class="container-header-light-normal"><span></span></div>
    <div class="copy clearfix">Error 404 - Not Found</div>
    <div class="container-footer-light-normal"><span></span></div>
</div>
<!-- SIDE BAR HERE -->
<?php get_sidebar(); ?>

<!-- FOOTER HERE -->
<?php get_footer(); ?>