<?php 
include_once (TEMPLATEPATH."/ocmx/widgets/flickr-widget.php");
include_once (TEMPLATEPATH."/ocmx/widgets/twitter-widget.php");
include_once (TEMPLATEPATH."/ocmx/widgets/advert-widget.php");
include_once (TEMPLATEPATH."/ocmx/widgets/four-block-widget.php");
include_once (TEMPLATEPATH."/ocmx/widgets/feature-post-widget.php");
include_once (TEMPLATEPATH."/ocmx/widgets/ocmx-latest-comments.php");
?>